﻿using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using RabbitMQ.Client;

namespace RabbitMQProducer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Task.Factory.StartNew(() =>
            {
                StartDirectProducer();
            });

            Task.Factory.StartNew(() =>
            {
                //StartFanoutProducer();
                
            });

            Task.Factory.StartNew(() =>
            {
                
            });


            Console.ReadLine();
        }

        #region Direct Exchange

        public static void StartDirectProducer()
        {
            var factory = new ConnectionFactory();
            factory.HostName = "127.0.0.1";
            factory.Port = 5672;
            factory.UserName = "guest";
            factory.Password = "guest";

            using (var connection = factory.CreateConnection())
            {
                using (var channel = connection.CreateModel())
                {
                    var exchangeName = "direct-exchange-example-true";

                    RegisterUserInfoCommand command = new RegisterUserInfoCommand()
                    {
                        Id = Guid.NewGuid().ToString(),
                        UserName = DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                        Password = DateTime.Now.ToString(),
                        VeriCode = "1324"
                    };

                    //Durable:True则代表是一个持久的队列
                    channel.ExchangeDeclare(exchangeName, ExchangeType.Direct, true);

                    //Durable:True则代表是一个持久的队列；
                    //Exclusive:如果是true，那么申明这个queue的connection断了，那么这个队列就被删除了，包括里面的消息；
                    //autoDelete:般都会输入false。true：如果这个queue不再使用（没有被订阅）的话，server就会删除它；
                    channel.QueueDeclare("direct-exchange-consuemr-1", true, false, false, null);
                    channel.QueueDeclare("direct-exchange-consuemr-2", true, false, false, null);

                    channel.QueueBind("direct-exchange-consuemr-1", exchangeName, "guest");
                    channel.QueueBind("direct-exchange-consuemr-2", exchangeName, "admin");

                    var properties = channel.CreateBasicProperties();
                    properties.SetPersistent(true); //===DeliveryMode:2

                    while (true)
                    {
                        var routingKey = DateTime.Now.Second%2 == 0 ? "guest" : "admin";

                        Console.WriteLine("publish => routingKey={0};data={1}", routingKey,
                            JsonConvert.SerializeObject(command));

                        Console.WriteLine("\n");

                        channel.BasicPublish(exchangeName, routingKey, properties,
                            Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(command)));
                        Thread.Sleep(500);
                    }
                }
            }
        }

        #endregion

        #region Fanout Exchange
        private static void StartFanoutProducer()
        {
            var factory = new ConnectionFactory();
            factory.HostName = "127.0.0.1";
            factory.Port = 5672;
            factory.UserName = "guest";
            factory.Password = "guest";

            using (var connection = factory.CreateConnection())
            {
                using (var channel = connection.CreateModel())
                {
                    var exchangeName = "fanout-exchange-example-true";

                    //Durable:True则代表是一个持久的队列
                    channel.ExchangeDeclare(exchangeName, ExchangeType.Fanout, true);

                    //Durable:True则代表是一个持久的队列；
                    //Exclusive:如果是true，那么申明这个queue的connection断了，那么这个队列就被删除了，包括里面的消息；
                    //autoDelete:般都会输入false。true：如果这个queue不再使用（没有被订阅）的话，server就会删除它；
                    //绑定到消息队列，如果在消费者出绑定消息队列，必须先开启COnsumer服务
                    channel.QueueDeclare("fanout-exchange-consumer-1", true, false, false, null);
                    channel.QueueDeclare("fanout-exchange-consumer-2", true, false, false, null);
                    channel.QueueDeclare("fanout-exchange-consumer-3", true, false, false, null);
                    channel.QueueDeclare("fanout-exchange-consumer-4", true, false, false, null);
                    channel.QueueDeclare("fanout-exchange-consumer-5", true, false, false, null);

                    //routingKey="";
                    channel.QueueBind("fanout-exchange-consumer-1", exchangeName, "");
                    channel.QueueBind("fanout-exchange-consumer-2", exchangeName, "");
                    channel.QueueBind("fanout-exchange-consumer-3", exchangeName, "");
                    channel.QueueBind("fanout-exchange-consumer-4", exchangeName, "");
                    channel.QueueBind("fanout-exchange-consumer-5", exchangeName, "");


                    var properties = channel.CreateBasicProperties();
                    properties.DeliveryMode = 2; //持久化
                    while (true)
                    {
                        ModifyUserInfoCommand cmd = new ModifyUserInfoCommand()
                        {
                            Id = Guid.NewGuid().ToString(),
                            UserName = DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                            Password = DateTime.Now.ToString(),
                            VeriCode = "1324"
                        };

                        var data = JsonConvert.SerializeObject(cmd);
                        Console.WriteLine("ExchangeName ={0},data={1}", exchangeName, data);
                       
                        channel.BasicPublish(exchangeName, "", properties,
                            Encoding.UTF8.GetBytes(data));
                       
                        Thread.Sleep(1000);
                    }
                }
            }
        }
        #endregion

        public class ModifyUserInfoCommand
        {
            public string Id { get; set; }
            public string UserName { get; set; }

            public string Password { get; set; }

            public string VeriCode { get; set; }

            public override string ToString()
            {
                return string.Format("Id={0},UserName={1},Password={2},VeriCode={3}", Id, UserName, Password, VeriCode);
            }
        }

        public class RegisterUserInfoCommand
        {
            public string Id { get; set; }
            public string UserName { get; set; }

            public string Password { get; set; }

            public string VeriCode { get; set; }

            public override string ToString()
            {
                return string.Format("Id={0},UserName={1},Password={2},VeriCode={3}", Id, UserName, Password, VeriCode);
            }
        }
    }
}
