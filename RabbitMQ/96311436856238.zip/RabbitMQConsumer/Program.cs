﻿using System;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace RabbitMQConsumer
{
    public class Program
    {
        private static void Main(string[] args)
        {

            Task.Factory.StartNew(() =>
            {
                StartDirectConsumer("direct-exchange-consuemr-1", "guest");
            });

            Task.Factory.StartNew(() =>
            {
                StartDirectConsumer("direct-exchange-consuemr-2", "admin");
            });

            //Task.Factory.StartNew(() =>
            //{
            //    StartFanoutConsumer("fanout-exchange-consumer-1");
            //});

            //Task.Factory.StartNew(() =>
            //{
            //    StartFanoutConsumer("fanout-exchange-consumer-2");
            //});

            //Task.Factory.StartNew(() =>
            //{
            //    StartFanoutConsumer("fanout-exchange-consumer-3");
            //});

            //Task.Factory.StartNew(() =>
            //{
            //    StartFanoutConsumer("fanout-exchange-consumer-4");
            //});
            //Task.Factory.StartNew(() =>
            //{
            //    StartFanoutConsumer("fanout-exchange-consumer-5");
            //});

            Task.Factory.StartNew(() =>
            {
                StartPushConsumer("fanout-exchange-consumer-4");
            });
            Console.ReadLine();
        }

        #region
        public static void StartDirectConsumer(string queueName, string routingKey)
        {
            var factory = new ConnectionFactory();
            factory.HostName = "127.0.0.1";
            factory.Port = 5672;
            factory.UserName = "guest";
            factory.Password = "guest";

            using (var connection = factory.CreateConnection())
            {
                using (var channel = connection.CreateModel())
                {
                    var exchangeName = "direct-exchange-example-true";
                   
                    channel.ExchangeDeclare(exchangeName, ExchangeType.Direct, true);
                  
                    channel.QueueDeclare(queueName, true, false, false, null);
                   
                    channel.QueueBind(queueName, exchangeName, routingKey);

                    QueueingBasicConsumer consumer = new QueueingBasicConsumer(channel);

                    //noack
                    channel.BasicConsume(queueName, false, consumer);

                    while (true) //poll
                    {
                        var queue = consumer.Queue.Dequeue();
                        var data = Encoding.UTF8.GetString(queue.Body);

                        Console.WriteLine("consumer => routingKey={0};queueName={1};data={2}", queue.RoutingKey, queueName, data);
                        Console.WriteLine("\n");

                        channel.BasicAck(queue.DeliveryTag, true);

                        Thread.Sleep(2000);

                    }
                }
            }


        }
        #endregion

        #region ExchangeType.Fanout

        private static void StartFanoutConsumer(string queueName)
        {
            var factory = new ConnectionFactory();
            factory.HostName = "127.0.0.1";
            factory.Port = 5672;
            factory.UserName = "guest";
            factory.Password = "guest";

            using (var connection = factory.CreateConnection())
            {
                using (var channel = connection.CreateModel())
                {
                    var exchangeName = "fanout-exchange-example-true";
                    channel.ExchangeDeclare(exchangeName, ExchangeType.Fanout, true);
                    channel.QueueDeclare(queueName, true, false, false, null);
                    channel.QueueBind(queueName, exchangeName, "");

                    QueueingBasicConsumer consumer = new QueueingBasicConsumer(channel);
                    var s = channel.BasicConsume(queueName, false, consumer);
                    while (true)
                    {
                        var queue = consumer.Queue.Dequeue();
                        var data = Encoding.UTF8.GetString(queue.Body);
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(data);
                        Console.WriteLine("\n");
                        Console.ForegroundColor = ConsoleColor.White;
                        channel.BasicAck(queue.DeliveryTag, true);
                        Thread.Sleep(1000);
                    }

                }
            }
        }

        /// <summary>
        /// consumer push 模型
        /// </summary>
        /// <param name="queueName"></param>
        private static void StartPushConsumer(string queueName)
        {
            var factory = new ConnectionFactory();
            factory.HostName = "127.0.0.1";
            factory.Port = 5672;
            factory.UserName = "guest";
            factory.Password = "guest";

            var connection = factory.CreateConnection();

            var channel = connection.CreateModel();

            var exchangeName = "fanout-exchange-example-true";

            channel.ExchangeDeclare(exchangeName, ExchangeType.Fanout, true);

            channel.QueueDeclare(queueName, true, false, false, null);

            channel.QueueBind(queueName, exchangeName, "");

            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (sender, basicDeliverEventArgs) =>
            {
                var data = Encoding.UTF8.GetString(basicDeliverEventArgs.Body);
                Console.WriteLine("push consumer {0}",data);

                channel.BasicAck(basicDeliverEventArgs.DeliveryTag, true);
            };

            channel.BasicConsume(queueName, false, consumer);
        }

        #endregion

    }
}
